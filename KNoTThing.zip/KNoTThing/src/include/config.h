#ifndef __HAL_CONFIG_H__
#define __HAL_CONFIG_H__

#define THING_NAME "thingname"


#endif /* __HAL_CONFIG_H__ */
